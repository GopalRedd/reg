package com.my360crm.my360reg.CustomerDetailsPackage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.my360crm.my360reg.CircularProgressdialog.circularprogresssdialog;
import com.my360crm.my360reg.R;
import com.my360crm.my360reg.RegCamerapackage.RegCamera;
import com.my360crm.my360reg.RegistrationPackage.Registration;

import java.util.Objects;

public class Customer_information extends AppCompatActivity {


    private static final String TAG = Customer_information.class.getSimpleName() ;
    TextView fullname,emailid,bussinessname,phonenumber;
    private Bitmap b;
    ImageView profilepic;
    Bundle bundle;

    String firstname,lastname,fullname1,email,company,phone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_information);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        fullname = findViewById(R.id.name);
        bussinessname = findViewById(R.id.businessname);
        emailid = findViewById(R.id.emailtext);
        phonenumber = findViewById(R.id.phonetext);
        profilepic = findViewById(R.id.olduser_profile_photo);
        bundle = getIntent().getExtras();
        assert bundle != null;
        if(getIntent().hasExtra("image")) {
            b = BitmapFactory.decodeByteArray(
                    getIntent().getByteArrayExtra("image"),0,getIntent().getByteArrayExtra("image").length);
            profilepic.setImageBitmap(getCircularBitmap(b));

        firstname        = bundle.getString("fistname");
        lastname        =  bundle.getString("lastname");
        fullname1      = firstname + " "+lastname;
        email         = bundle.getString("email");
        company       = bundle.getString("company");
        phone       = bundle.getString("phone");
        Log.i(TAG, "\n===========================" + "\nfullname " + fullname + "\n" + "email " + email + "\n" + "company " + company + "\n" + "phone " + phone + "\n" + "===========================\n");

        }

      fullname.setText(fullname1);
      emailid.setText(email);
      bussinessname.setText(company);
      phonenumber.setText(phone);


    }

    private Bitmap getCircularBitmap(Bitmap bitmap) {

        Bitmap output;
        if (bitmap.getWidth() > bitmap.getHeight()) {
            output = Bitmap.createBitmap(bitmap.getHeight(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        } else {
            output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

        float r = 0;

        if (bitmap.getWidth() > bitmap.getHeight()) {
            r = bitmap.getHeight() / 2;
        } else {
            r = bitmap.getWidth() / 2;
        }

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawCircle(r, r, r, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return output;
    }

    @Override
    public boolean onSupportNavigateUp() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(Customer_information.this, RegCamera.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        },1000);

        return true;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cancel_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.cancel) {
            circularprogresssdialog.showDialog(Customer_information.this, "", "");
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    circularprogresssdialog.dismissdialog();
                    startActivity(new Intent(Customer_information.this, RegCamera.class));
                    finish();
                }
            }, 2000);


            return true;
        }
        return super.onOptionsItemSelected(item);
    }



}
