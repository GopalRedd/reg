package com.my360crm.my360reg.RegistrationPackage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.my360crm.my360reg.CircularProgressdialog.circularprogresssdialog;
import com.my360crm.my360reg.CustomerDetailsPackage.Customer_information;
import com.my360crm.my360reg.JsonNetworkPackage.MultipartRequest;
import com.my360crm.my360reg.R;
import com.my360crm.my360reg.RegCamerapackage.ImagePreview;
import com.my360crm.my360reg.RegCamerapackage.RegCamera;
import com.my360crm.my360reg.StartCamera;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class Registration extends AppCompatActivity {

    private  static final  String TAG = Registration.class.getSimpleName() ;
    private Bitmap b;


    public TextInputEditText firstname,lastname,business,emailid,contactnumber;
    public EditText comment ;
    public Button submit,cancel;
    public ImageView profilepic;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        firstname = findViewById(R.id.fnameedit);
        lastname = findViewById(R.id.lnameedit);
        business = findViewById(R.id.bussinessedit);
        emailid  = findViewById(R.id.emailedt);
        contactnumber = findViewById(R.id.phoneedt);
        comment = findViewById(R.id.comment);
        submit = findViewById(R.id.registernow);

        profilepic = findViewById(R.id.reguser_profile_photo);
        if (getIntent().hasExtra("image"))
        {
            b = BitmapFactory.decodeByteArray(getIntent().getByteArrayExtra("image"), 0, Objects.requireNonNull(getIntent().getByteArrayExtra("image")).length);

            profilepic.setImageBitmap(getCircularBitmap(b));
            Log.i(TAG,b.toString());
        }


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String fn = Objects.requireNonNull(firstname.getText()).toString();
                String ln =  Objects.requireNonNull(lastname.getText()).toString();
                String em =  Objects.requireNonNull(emailid.getText()).toString();
                String pn =  Objects.requireNonNull(contactnumber.getText()).toString();
                String bn = Objects.requireNonNull(business.getText()).toString();
                String com = comment.getText().toString();

                if(fn.isEmpty())
                {
                    firstname.setError("First Name is must");
                } else if(ln.isEmpty())
                {
                    lastname.setError("Last Name is must");
                }else if(em.isEmpty())
                {
                    emailid.setError("Email is must");
                }else if(pn.length()<10)
                {
                    contactnumber.setError("Contact number is must");
                } else if(bn.length()<0)
                {
                    business.setError("Bussiness Name is must");
                } else if(com.length()<0)
                {
                    comment.setError("Comment   is must");
                } else
                {
                    Uploadtoserver(fn,ln,em,pn,bn,com,b);
                }


            }
        });



        }



    private Bitmap getCircularBitmap(Bitmap bitmap) {

        Bitmap output;
        if (bitmap.getWidth() > bitmap.getHeight()) {
            output = Bitmap.createBitmap(bitmap.getHeight(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        } else {
            output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

        float r = 0;

        if (bitmap.getWidth() > bitmap.getHeight()) {
            r = bitmap.getHeight() / 2;
        } else {
            r = bitmap.getWidth() / 2;
        }

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawCircle(r, r, r, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return output;
    }


    @Override
    public boolean onSupportNavigateUp() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(Registration.this,RegCamera.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        },1000);

        return true;
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cancel_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.cancel) {
            circularprogresssdialog.showDialog(Registration.this, "", "");
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    circularprogresssdialog.dismissdialog();
                    startActivity(new Intent(Registration.this, RegCamera.class));
                    finish();
                }
            }, 2000);


            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void Uploadtoserver(final String fn, final String ln, final String em, final String pn, final String bn, final String com, final Bitmap b) {

        circularprogresssdialog.showDialog(Registration.this, "", "");
        MultipartRequest multipartRequest = new MultipartRequest(Request.Method.POST, "https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/My360Register_Create.php", new Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                circularprogresssdialog.dismissdialog();
                try {
                    JSONObject obj = new JSONObject(new String(response.data));
                    Log.i(TAG,obj.toString());
                    String Status = obj.getString("status");

                    if(Status.equals("success"))
                    {
                        String Name = obj.getString("name");
                        Snackbar.make(findViewById(android.R.id.content),Name+" Successfully Registered",Snackbar.LENGTH_LONG).show();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Intent intent = new Intent(Registration.this, StartCamera.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                            }
                        },1000);

                    }else if(Status.equals("error"))
                    {
                        String message = obj.getString("server error");
                        Snackbar.make(findViewById(android.R.id.content),message,Snackbar.LENGTH_LONG).show();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Intent intent = new Intent(Registration.this,StartCamera.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                            }
                        },1000);

                    }else
                    {
                        Snackbar.make(findViewById(android.R.id.content),"Please Try again",Snackbar.LENGTH_LONG).show();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Intent intent = new Intent(Registration.this,StartCamera.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                            }
                        },1000);

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                circularprogresssdialog.dismissdialog();

                Snackbar.make(findViewById(android.R.id.content),"Bad Internet!",Snackbar.LENGTH_LONG).show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(Registration.this,StartCamera.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    }
                },1000);



            }
        }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

/*
                params.put("tags", tags);
*/
            params.put("first_name",fn);
            params.put("last_name",ln);
            params.put("business_name",bn);
            params.put("email",em);
            params.put("phone",pn);
            params.put("comment",com);


                return params;
            }


            /*
             * Here we are passing image by renaming it with a unique name
             *
             */

            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                long imagename = System.currentTimeMillis();
                params.put("image", new DataPart(imagename + ".jpeg", getFileDataFromDrawable(b)));
                return params;
            }

        };
        multipartRequest.setRetryPolicy(new DefaultRetryPolicy(
                0, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        Volley.newRequestQueue(this).add(multipartRequest);


    }
    private byte[] getFileDataFromDrawable(Bitmap bitmap) {
        if(bitmap != null)
        {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, byteArrayOutputStream);
            Log.i(TAG,byteArrayOutputStream.toByteArray().toString());
            return byteArrayOutputStream.toByteArray();

        } else
        {
            Log.i(TAG,"Bitmap is Empty ");

            return null;
        }


    }
}


