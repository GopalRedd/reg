package com.my360crm.my360reg;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.crashlytics.android.Crashlytics;
import com.google.android.material.snackbar.Snackbar;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.my360crm.my360reg.CircularProgressdialog.circularprogresssdialog;
import com.my360crm.my360reg.RegCamerapackage.RegCamera;
import com.novoda.merlin.Connectable;
import com.novoda.merlin.Merlin;
import com.novoda.merlin.MerlinsBeard;

import io.fabric.sdk.android.Fabric;

import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    Context context = this;
    PackageManager packageManager;
    private Merlin merlin;
    private MerlinsBeard merlinsBeard;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Fabric.with(this, new Crashlytics());
        setContentView(R.layout.activity_main);
        Objects.requireNonNull(getSupportActionBar()).hide();
        Log.i(TAG,TAG +" Startred");
        merlin = new Merlin.Builder().withConnectableCallbacks().build(context);
        merlinsBeard = MerlinsBeard.from(this);

        packageManager = context.getPackageManager();
        if ((packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA)) && (packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT)))
        {
            Log.i(TAG,"Camera's are their ");
            PermissionsFirst();
        } else
        {
            circularprogresssdialog.showAlertDialgo(MainActivity.this,"This System don't have cameras!","Warning");

        }

        merlin.registerConnectable(new Connectable() {
            @Override
            public void onConnect()
            {

            }
        });

        if(merlinsBeard.isConnected())
        {

            // nothing
            Snackbar.make(findViewById(android.R.id.content),"Good Connected to internet!",Snackbar.LENGTH_LONG).show();

        }else
        {
            //show alertdialog

            circularprogresssdialog.showAlertDialgo(MainActivity.this,"You need to have Mobile Data or wifi to access this","Bad Internet");
        }

    }

    private void PermissionsFirst() {
        Dexter.withActivity(this)
                .withPermissions(
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.CAMERA)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted())
                        {
                            circularprogresssdialog.showDialog(MainActivity.this,"","");
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    circularprogresssdialog.dismissdialog();
                                    startActivity(new Intent(MainActivity.this, StartCamera.class));
                                    finish();
                                }
                            },2000);


                        }
                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings
                            showSettingsDialog();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(getApplicationContext(), "Error occurred! ", Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();

    }

    private void showSettingsDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Need Permissions");
        builder.setMessage("This app needs permission to use this feature. You can grant them in app settings.");
        builder.setPositiveButton("GOTO SETTINGS", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                openSettings();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }

    private void openSettings() {

        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }

    @Override
    protected void onPause() {
        merlin.unbind();
        super.onPause();
    }


    @Override
    protected void onResume() {
        super.onResume();
        merlin.bind();

    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        merlin.unbind();

    }


}
